package com.mycompany.shortestpathmap1;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class PathVisualizer extends JPanel {
    private Graph graph;
    private Node selectedSourceNode;
    private Node selectedDestinationNode;
    private List<Node> shortestPath = new ArrayList<>();

    // Define colors for visualization
    private static final Color BACKGROUND_COLOR = new Color(224, 255, 255); // Light cyan for better visibility
    private static final Color NODE_COLOR = new Color(255, 140, 0); // Orange for nodes (houses)
    private static final Color EDGE_COLOR = new Color(0, 100, 0); // Dark green for edges (roads)
    private static final Color PATH_COLOR = new Color(255, 215, 0); // Gold for highlighting the shortest path

    public PathVisualizer(Graph graph) {
        this.graph = graph;
        setPreferredSize(new Dimension(800, 600));
        setBackground(BACKGROUND_COLOR); // Set the background color
    }

    public void setSelectedSourceNode(Node node) {
        this.selectedSourceNode = node;
        repaint();
    }

    public void setSelectedDestinationNode(Node node) {
        this.selectedDestinationNode = node;
        repaint();
    }

    public void setShortestPath(List<Node> path) {
        this.shortestPath = path;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        drawGraph(g);
    }

    private void drawGraph(Graphics g) {
        // Draw all edges
        g.setColor(EDGE_COLOR); // Set color for edges
        for (Node node : graph.getNodes().values()) {
            for (Edge edge : node.getEdges()) {
                Node toNode = edge.getTo();
                g.drawLine(node.getX(), node.getY(), toNode.getX(), toNode.getY());
                // Display edge weights
                int midX = (node.getX() + toNode.getX()) / 2;
                int midY = (node.getY() + toNode.getY()) / 2;
                g.setColor(Color.BLACK);
                g.drawString(String.valueOf(edge.getWeight()), midX, midY);
                g.setColor(EDGE_COLOR); // Reset color for edges
            }
        }

        // Draw all nodes
        for (Node node : graph.getNodes().values()) {
            // Draw a house-like shape (simple rectangle for this example)
            g.setColor(NODE_COLOR);
            g.fillRect(node.getX() - 15, node.getY() - 20, 30, 20); // House shape
            g.setColor(Color.BLACK);
            g.drawRect(node.getX() - 15, node.getY() - 20, 30, 20); // Outline of the house
            g.drawString(node.getName(), node.getX() - 10, node.getY() - 25); // Draw node name
        }

        // Highlight source and destination nodes
        if (selectedSourceNode != null) {
            g.setColor(Color.GREEN);
            g.fillOval(selectedSourceNode.getX() - 20, selectedSourceNode.getY() - 10, 40, 40);
        }
        if (selectedDestinationNode != null) {
            g.setColor(Color.RED);
            g.fillOval(selectedDestinationNode.getX() - 20, selectedDestinationNode.getY() - 10, 40, 40);
        }

        // Highlight the shortest path with a box
        if (!shortestPath.isEmpty()) {
            g.setColor(PATH_COLOR); // Color for the path
            for (Node node : shortestPath) {
                g.fillRect(node.getX() - 15, node.getY() - 20, 30, 20); // Draw highlighted box for each node in the path
                g.setColor(Color.BLACK);
                g.drawRect(node.getX() - 15, node.getY() - 20, 30, 20); // Outline for visibility
            }
        }
    }
}

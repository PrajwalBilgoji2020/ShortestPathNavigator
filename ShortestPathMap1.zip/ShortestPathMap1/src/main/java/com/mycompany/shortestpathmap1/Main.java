package com.mycompany.shortestpathmap1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class Main {
    private Graph graph;
    private PathVisualizer pathVisualizer;

    public Main() {
        graph = new Graph();
        setupGraph(); // Initialize the graph with nodes and edges
        createGUI();
    }

    private void setupGraph() {
        // Add nodes and coordinates
        graph.addNode("austin", 50, 200);
        graph.addNode("bali", 300, 100);
        graph.addNode("cairo", 300, 200);
        graph.addNode("dubai", 300, 300);
        graph.addNode("essa", 500, 100);
        graph.addNode("fes", 500, 200);
        graph.addNode("giza", 500, 300);
        graph.addNode("hilo", 700, 50);
        graph.addNode("izmir", 700, 150);
        graph.addNode("jinan", 700, 300);
        graph.addNode("kilo", 700, 400);
        graph.addNode("lima", 950, 150);
        graph.addNode("malta", 900, 200);
        graph.addNode("nice", 900, 300);
        graph.addNode("oslo", 1100, 100);
        graph.addNode("paris", 1100, 200);
        graph.addNode("quito", 1100, 300);
        graph.addNode("rota", 1100, 400);
        graph.addNode("suva", 1250, 100);
        graph.addNode("tibet", 1250, 300);
        graph.addNode("zadar", 1400, 200);

        // Adding edges with weights 
        graph.addEdge("austin", "bali", 2);
        graph.addEdge("austin", "cairo", 4);
        graph.addEdge("austin", "dubai", 1);
        graph.addEdge("bali", "cairo", 3);
        graph.addEdge("bali", "essa", 1);
        graph.addEdge("cairo", "fes", 2);
        graph.addEdge("cairo", "essa", 2);
        graph.addEdge("dubai", "giza", 4);
        graph.addEdge("dubai", "fes", 5);
        graph.addEdge("essa", "hilo", 3);
     
        graph.addEdge("fes", "izmir", 2);
        graph.addEdge("fes", "hilo", 3);
        graph.addEdge("fes", "giza", 3);
        graph.addEdge("fes", "jinan", 4);
        graph.addEdge("giza", "kilo", 2);
        graph.addEdge("hilo", "lima", 1);
        graph.addEdge("izmir", "malta", 2);
        graph.addEdge("izmir", "jinan", 3);
        graph.addEdge("izmir", "lima", 3);
        graph.addEdge("jinan", "kilo", 6);
        
        graph.addEdge("jinan", "malta", 6);
        graph.addEdge("jinan", "nice", 3);
        graph.addEdge("lima", "malta", 3);
        graph.addEdge("lima", "oslo", 6);
        graph.addEdge("malta", "nice", 5);
        graph.addEdge("malta", "oslo", 4);
        graph.addEdge("malta", "paris", 2);
        graph.addEdge("nice", "rota", 1);
        graph.addEdge("kilo", "rota", 2);
        graph.addEdge("kilo", "nice", 4);
        
        graph.addEdge("oslo", "suva", 6);
        graph.addEdge("oslo", "paris", 2);
        graph.addEdge("paris", "quito", 1);
        graph.addEdge("paris", "suva", 2);
        graph.addEdge("quito", "rota", 8);
        graph.addEdge("quito", "tibet", 3);
        graph.addEdge("rota", "tibet", 5);
        graph.addEdge("suva", "zadar", 2);
        graph.addEdge("tibet", "zadar", 8);
        graph.addEdge("malta", "quito", 5);
        
        graph.addEdge("paris", "tibet", 1);
        graph.addEdge("hilo", "oslo", 8);
    }

    private void createGUI() {
        JFrame frame = new JFrame("Graph Visualization and Shortest Path Finder");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        frame.setLayout(new BorderLayout());

        // Panel for the campus map visualization
        pathVisualizer = new PathVisualizer(graph);
        frame.add(pathVisualizer, BorderLayout.CENTER);

        // Panel for the shortest path functionality
        JPanel controlPanel = new JPanel();
        controlPanel.setLayout(new FlowLayout());

        JTextField sourceField = new JTextField(20);
        JTextField destinationField = new JTextField(20);
        JButton findButton = new JButton("Find Shortest Path");
        JTextArea resultArea = new JTextArea(8, 50);
        resultArea.setEditable(false);

        findButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String source = sourceField.getText().toLowerCase();
                String destination = destinationField.getText().toLowerCase();
                DijkstraAlgorithm dijkstra = new DijkstraAlgorithm();
                List<Node> path = dijkstra.findShortestPath(graph, source, destination);
                
                pathVisualizer.setShortestPath(path);
                
                if (path != null && !path.isEmpty()) {
                    pathVisualizer.setSelectedSourceNode(graph.getNodes().get(source));
                    pathVisualizer.setSelectedDestinationNode(graph.getNodes().get(destination));
                    resultArea.setText("Shortest Path: " + path);
                } else {
                    resultArea.setText("Path not found or invalid input.");
                }
            }
        });

        controlPanel.add(new JLabel("Source:"));
        controlPanel.add(sourceField);
        controlPanel.add(new JLabel("Destination:"));
        controlPanel.add(destinationField);
        controlPanel.add(findButton);
        controlPanel.add(new JScrollPane(resultArea));

        frame.add(controlPanel, BorderLayout.SOUTH);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Main::new);
    }
}

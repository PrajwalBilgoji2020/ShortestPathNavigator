package com.mycompany.shortestpathmap1;

import java.util.*;

public class DijkstraAlgorithm {
    public List<Node> findShortestPath(Graph graph, String startName, String endName) {
        Node startNode = graph.getNodes().get(startName);
        Node endNode = graph.getNodes().get(endName);
        
        if (startNode == null || endNode == null) {
            return null;  // Invalid source or destination
        }

        Map<Node, Node> previousNodeMap = new HashMap<>();
        Map<Node, Integer> distanceMap = new HashMap<>();
        PriorityQueue<Node> pq = new PriorityQueue<>(Comparator.comparingInt(distanceMap::get));
        
        for (Node node : graph.getNodes().values()) {
            distanceMap.put(node, Integer.MAX_VALUE);
        }
        distanceMap.put(startNode, 0);
        pq.add(startNode);

        while (!pq.isEmpty()) {
            Node current = pq.poll();
            if (current == endNode) break;  // We reached the destination

            for (Edge edge : current.getEdges()) {
                Node neighbor = edge.getTo();
                int newDist = distanceMap.get(current) + edge.getWeight();
                
                if (newDist < distanceMap.get(neighbor)) {
                    distanceMap.put(neighbor, newDist);
                    previousNodeMap.put(neighbor, current);
                    pq.add(neighbor);
                }
            }
        }

        return buildPath(previousNodeMap, startNode, endNode);
    }

    private List<Node> buildPath(Map<Node, Node> previousNodeMap, Node startNode, Node endNode) {
        List<Node> path = new ArrayList<>();
        Node currentNode = endNode;

        while (currentNode != null) {
            path.add(currentNode);
            currentNode = previousNodeMap.get(currentNode);
        }

        Collections.reverse(path);

        // If startNode isn't part of the path, that means no valid path was found
        if (path.isEmpty() || path.get(0) != startNode) {
            return null;
        }

        return path;
    }
}

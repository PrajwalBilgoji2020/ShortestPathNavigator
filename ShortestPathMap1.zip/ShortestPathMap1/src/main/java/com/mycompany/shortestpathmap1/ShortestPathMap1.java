/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.shortestpathmap1;


import javax.swing.SwingUtilities;

public class ShortestPathMap1 {
    public static void main(String[] args) {
        // Use SwingUtilities to ensure thread safety for GUI creation
        SwingUtilities.invokeLater(() -> {
            new Main(); // Initialize the Main class which sets up the GUI and graph
        });
    }
}


package com.mycompany.shortestpathmap1;

import java.util.HashMap;
import java.util.Map;

public class Graph {
    private Map<String, Node> nodes = new HashMap<>();

    public void addNode(String name, int x, int y) {
        nodes.put(name.toLowerCase(), new Node(name.toLowerCase(), x, y));
    }

    public void addEdge(String fromName, String toName, int weight) {
        Node fromNode = nodes.get(fromName.toLowerCase());
        Node toNode = nodes.get(toName.toLowerCase());
        
        if (fromNode != null && toNode != null) {
            fromNode.addEdge(toNode, weight);
        }
    }

    public Map<String, Node> getNodes() {
        return nodes;
    }
}
